from django.apps import AppConfig


class Task5Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'task5'
