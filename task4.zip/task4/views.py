from django.shortcuts import render

def home(request):
    games = ['Atomic Heart', 'Cyberpunk 2077']
    return render(request, 'fourth_task/home.html', {'games': games})

def shop(request):
    items = {
        'item1': 'Игровая консоль',
        'item2': 'Игровая мышь',
        'item3': 'Игровая клавиатура',
       }
    return render(request, 'fourth_task/shop.html', {'items': items})

def cart(request):
    return render(request, 'fourth_task/cart.html')

# Create your views here.
