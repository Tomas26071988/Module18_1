from django.urls import path
from .views import function_view, ClassView, home_view

urlpatterns = [
    path('', home_view, name='home'),
    path('function/', function_view, name='function_view'),  # маршрутизируем к function_view
    path('class/', ClassView.as_view(), name='class_view'),  # маршрутизируем к ClassView
]